create definer = root@localhost trigger set_complaint_status_active
    before insert
    on electricity_complaint
    for each row
BEGIN
    SET NEW.complaint_status = 'ACTIVE';
END;

