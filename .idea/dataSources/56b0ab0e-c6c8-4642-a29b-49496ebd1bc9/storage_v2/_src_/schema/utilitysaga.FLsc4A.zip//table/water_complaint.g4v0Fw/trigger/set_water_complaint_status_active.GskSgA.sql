create definer = root@localhost trigger set_water_complaint_status_active
    before insert
    on water_complaint
    for each row
BEGIN
    SET NEW.complaint_status = 'ACTIVE';
END;

